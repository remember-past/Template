__author__ = 'Leonardo Taccari'
__email__ = 'leonardo.taccari@gmail.com'
__version__ = '0.2.5'

from .joyplot import joyplot, plot_density, _joyplot
